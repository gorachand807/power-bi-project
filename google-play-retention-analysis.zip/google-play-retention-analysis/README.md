# Google Play Store — D7 Retention Analysis
**Target Role: Data Analyst, Early Career - L3, Hyderabad (Google)**

### Business Problem
Why are users dropping off after Day 7 on Google Play? 77% uninstall within 7 days.
Goal: Identify drivers of 7-day retention drop and test intervention to improve activation & reduce churn.
Impact: Improve D7 retention to boost LTV and reduce acquisition cost.

### Metrics
- D1 Retention: 42.8%
- D7 Retention: 22.1% (Primary, +7.2% lift with treatment)
- D30 Retention: 9.6%
- Uninstall Rate: 5.3% (-1.1pp WoW)

### Project Flow
SQL Modeling (BigQuery, Window Functions) -> EDA (Cohort breakdown) -> A/B Test Design (Control vs Treatment) -> Dashboard (Looker Studio) -> Executive Memo

### Tech Stack
- BigQuery SQL: CTEs, Window functions, Cohort tables
- Python: pandas, scipy (t-test, hypothesis testing), matplotlib/seaborn
- Looker Studio: Interactive dashboard
- GitHub

### Key Insights
- Retention drop most severe Day 5-7
- Treatment (in-app tutorial tooltip) improved D7 by +7.2pp (p<0.01, 95% CI [4.8%, 9.6%])
- Recommendation: Roll out tutorial to 100% users

### Resume Bullet
**Google Play Store Retention Analysis | SQL, Python, Looker Studio | [GitHub Link]**
Analyzed 10k+ apps to identify drivers of D7 uninstalls; built fact tables using CTEs & window functions in BigQuery, reducing query time by 60%. Designed A/B test for transparency tooltip feature, projecting +7.2% D7 retention with guardrail on installs; created executive dashboard for product decision.

### How to run
1. Load data/sample_events.csv into BigQuery
2. Run sql/01_create_cohort.sql, then 02_d7_retention.sql
3. Open analysis/retention_analysis.py
4. Run sql/03_ab_test_analysis.sql for stats
5. View dashboard link in dashboard/
